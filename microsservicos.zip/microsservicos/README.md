# Implementa��o de microsservi�os - Exemplo

## Descri��o

Implementa��o de uma aplica��o de Campanha e S�cio Torcedor.
O detalhamento est� em documento fornecido.

Cada camanha possui um per�odo de vig�ncia indicado por duas datas:
- data in�cio de vig�ncia
- data fim de vig�ncia

N�o ficou muito claro o que diferencia um per�odo de vig�ncia entre duas campanhas. 
Para  o desenvolvimento foi considerada a apenas a data de fim de vig�ncia. Ou seja, duas campanhas n�o podem ter a mesma data de fim de vig�ncia.

## Tecnologias utilizadas

- Springboot
- Lombok, para gera��o de *getters* , *setters* e padr�o *builder*
- EntityListener, para notifica��o/auditoria. Quando uma campanha for alterada, uma notifica��o � enviada no *PostUpdate*
- Feign, substituindo o uso do RestTemplate
- Hystrix, para implementa��o do padr�o *CircuitBreaker* e *Callback*
- EurekaServer, para implementa��o do *ServiceDiscoverer*
- Swagger, para documenta��o 

## Funcionamento

Foram desenvolvidas duas *APIs*:
- api-socio
- api-campanha

A *api-campanha* � respons�vel pela cria��o, altera��o, dele��o e listagem das campanhas. Como tamb�m, pela associa��o das camapanhas aos s�cios.

A *api-socio* � repsons�vel pela cria��o dos s�cios e associa��o �s campanhas.

Para o exemplo, a aplica��o j� carrega 4 times para utiliza��o:

``` json
    [
  {
    "id": 1,
    "nome": "Corinthians"
  },
  {
    "id": 2,
    "nome": "Palmeiras"
  },
  {
    "id": 3,
    "nome": "Santos"
  },
  {
    "id": 4,
    "nome": "Sao Paulo"
  }
]
```
E duas campanhas:

``` json
    [
  {
    "id": 5,
    "nomeCampanha": "Campanha 1",
    "dataIniVigencia": "2019-09-06",
    "dataFimVigencia": "2019-11-04",
    "timeId": 2,
    "nomeTime": "Palmeiras"
  },
  {
    "id": 6,
    "nomeCampanha": "Campanha 2",
    "dataIniVigencia": "2019-09-06",
    "dataFimVigencia": "2019-11-05",
    "timeId": 3,
    "nomeTime": "Santos"
  }
]
```

Tamb�m foi criada uma aplica��o para execu��o do EurekaServer.

## APIs

### api-campanha

JSON da Campanha:
```json
{
    "id": ,
    "nomeCampanha": "Campanha 1",
    "dataIniVigencia": "2019-09-06",
    "dataFimVigencia": "2019-11-04",
    "timeId": ,
    "nomeTime": "Nome Time"
  }
```
OBS: Formato da data *YYYY-MM-dd*


##### 1) Lista todas as campanhas (GET)
```
http://localhost:9090/api/v1/campanhas
```
##### 2) Cria uma campanha (POST) 
Neste caso � necess�rio saber o *id* do time para envi�-lo na requisi��o

```
http://localhost:9090/api/v1/campanhas
```
##### 3) Busca uma campanha espec�fica (GET)
� necess�rio saber o *id* da campanha  
```
http://localhost:9090/api/v1/campanhas/{id}
```
##### 4) Atualiza uma campanha (PUT)
� necess�rio saber o *id* da campanha
```
http://localhost:9090/api/v1/campanhas
```
##### 5) Deleta uma campanha (DELETE)
� necess�rio saber o *id* da campanha
```
http://localhost:9090/api/v1/campanhas/{id}
```

##### 6) Lista todos os times (GET)
```
http://localhost:9090/api/v1/times
```
##### 7) Associa um socio �s campanhas e retorna a lisa de campanhas (POST)
```
http://localhost:9090/api/v1/sociocampanhas
```

### api-socio

JSON do S�cio:
```json
{
  "dataNascimento": "YYYY-MM-dd",
  "email": "teste4@teste.com",
  "idSocio": 0,
  "nomeSocio": "Nome do s�cio",
  "timeId": 3
}
    
```

OBS: Neste caso o e-mail � utilizado como chave, ou seja, identifica unicamente o s�cio.

##### 1) Cria um socio e associa as campanhas
� necess�rio saber o *id* do time
```
http://localhost:8080/api/v1/socios
```

## Executando o exemplo



#### What you'll need

- JDK 1.8 or later
- Maven 3.2

#### Installing and Running

In the root directory, execute the command:

```
$ mvn spring-boot:run
```

#### Running the Tests

```
mvn clean install
```

#### Testing

The project is using *SWAGGER*, so, if the application is running, you can visit the url:
```
http://localhost:8080/swagger-ui.html
```
Or

you can use same *curl* examples:

- Create a Credit Card Payment:

```
curl -X POST "http://localhost:8080/services/payments" -H  "accept: */*" -H  "Content-Type: application/json" -d "{    \"paymentId\": null,    \"clientId\": 1,     \"amount\": 200,     \"type\": \"CREDIT_CARD\",    \"status\": null,    \"buyer\": {        \"buyerId\": null,        \"name\": \"Antonio Carlos\",        \"email\": \"antonio@gmail.com\",        \"cpf\": \"1234567-9\"    },    \"holderName\": \"Antonio Carlos\",    \"cardNumber\": \"378282246310005\",    \"cvv\": \"4\",    \"expirationDate\": \"2021-01-15\",    \"issuer\": null}"
```

- Create a Boleto Payment:
```
curl -X POST "http://localhost:8080/services/payments" -H  "accept: */*" -H  "Content-Type: application/json" -d "{    \"paymentId\": null,    \"clientId\": 1,     \"amount\": 200,     \"type\": \"BOLETO\",    \"status\": null,    \"buyer\": {        \"buyerId\": null,        \"name\": \"Antonio Carlos\",        \"email\": \"antonio@gmail.com\",        \"cpf\": \"1234567-9\"    },   \"barCode\": null}"
```

- Verify status: (YOU MUST REPLACE {paymentID} )
```
curl -X GET "http://localhost:8080/services/payments/{paymentId}/status" -H  "accept: */*"
```

## TO-DO

 - Improve Bean Validation: 
    - apply to service and persistence layers
    - CPF validation
 - Bar Code generator for Boleto Payment
 - Add security
 - Add logging
 - Improve tests 
 
 ## PLUS: Docker
 
 It´s possible run the application in simple Docker container.
 
 If you have Docker installed, run the command:
 ```
 mvn clean install dockerfile:build
 ```
 
 This should create the image: ``rformagio/wirecard-challenge``
 And now, to put services up and running:
 ```
 docker run -p 8080:8080 --name wirecard rformagio/wirecard-challenge
 ```
 
 You can test !!! The *URL*s are the same. 
 ```
 http://localhost:8080/swagger-ui.html
 ```
 
 That´s it !!
 
 
 
 
