package br.com.rformagio.socio.exception;

public class BusinessException extends Exception {

}
